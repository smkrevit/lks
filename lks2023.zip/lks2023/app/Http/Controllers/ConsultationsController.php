<?php

namespace App\Http\Controllers;

use App\Models\consultations;
use App\Http\Requests\StoreconsultationsRequest;
use App\Http\Requests\UpdateconsultationsRequest;

class ConsultationsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreconsultationsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(consultations $consultations)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(consultations $consultations)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateconsultationsRequest $request, consultations $consultations)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(consultations $consultations)
    {
        //
    }
}
