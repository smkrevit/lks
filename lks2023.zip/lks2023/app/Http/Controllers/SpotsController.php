<?php

namespace App\Http\Controllers;

use App\Models\spots;
use App\Http\Requests\StorespotsRequest;
use App\Http\Requests\UpdatespotsRequest;

class SpotsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        $spots = spots::join(
            'regionals','spots.regional_id','=','regionals.id'
        )
        ->get([ 'spots.*', 'regionals.*' ])
        ;

        return response()->json([

            'data' => $spots,
            'message' => 'OK',
            'status' => 1

        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorespotsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(spots $spots)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(spots $spots)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatespotsRequest $request, spots $spots)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(spots $spots)
    {
        //
    }
}
