<?php

namespace App\Http\Controllers;

use App\Models\regionals;
use App\Http\Requests\StoreregionalsRequest;
use App\Http\Requests\UpdateregionalsRequest;

class RegionalsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $regionals = regionals::all();
        return response()->json([
            'data'=>$regionals,
            'message' => 'OK'
        ]);

    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreregionalsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(regionals $regionals)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(regionals $regionals)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateregionalsRequest $request, regionals $regionals)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(regionals $regionals)
    {
        //
    }
}
