<?php

namespace App\Http\Controllers;

use App\Models\vaccinations;
use App\Http\Requests\StorevaccinationsRequest;
use App\Http\Requests\UpdatevaccinationsRequest;

class VaccinationsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $vaccinations = vaccinations::join(
            // menggabungkan tabel
          'socities','vaccinations.society_id','=','socities.id'  
        )->join('spots','vaccinations.spot_id','=','spots.id')
         ->join('vaccines','vaccinations.vaccine_id','=','vaccines.id')
         ->join('medicals','vaccinations.doctor_id','=','medicals.id')
         // menampilkan data
         ->get(['vaccinations.*','socities.*','spots.*','vaccines.*','medicals.*'])
        ;

        return response()->json([
            'data' => $vaccinations,
            'message' => 'OK',
            'status' => 1

        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StorevaccinationsRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(vaccinations $vaccinations)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(vaccinations $vaccinations)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatevaccinationsRequest $request, vaccinations $vaccinations)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(vaccinations $vaccinations)
    {
        //
    }
}
