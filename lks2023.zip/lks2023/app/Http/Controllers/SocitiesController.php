<?php

namespace App\Http\Controllers;

use App\Models\socities;
use App\Http\Requests\StoresocitiesRequest;
use App\Http\Requests\UpdatesocitiesRequest;

class SocitiesController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoresocitiesRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(socities $socities)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(socities $socities)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdatesocitiesRequest $request, socities $socities)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(socities $socities)
    {
        //
    }
}
