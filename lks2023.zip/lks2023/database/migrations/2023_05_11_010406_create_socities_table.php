<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('socities', function (Blueprint $table) {
            $table->id();
            $table->string('id_card_number');
            $table->string('password');
            $table->string('name_societies');
            $table->date('bom_date');
            $table->string('gender')->enum('male','female')->default('female');
            $table->string('address');
            $table->integer('regional_id');
            $table->string('login_token');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('socities');
    }
};
